package com.azure.billing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AzureBillingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AzureBillingApplication.class, args);
	}

}
