package com.azure.billing;

import com.azure.core.credential.TokenCredential;
import com.azure.core.management.AzureEnvironment;
import com.azure.core.management.profile.AzureProfile;
import com.azure.identity.DefaultAzureCredential;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.resourcemanager.billing.BillingManager;
import com.azure.resourcemanager.billing.models.BillingAccount;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillingController {

    @GetMapping("/billing")
    public String getBillingData() {
        AzureProfile profile = new AzureProfile(AzureEnvironment.AZURE);
        TokenCredential credential = new DefaultAzureCredentialBuilder()
                .authorityHost(profile.getEnvironment().getActiveDirectoryEndpoint())
                .build();
        BillingManager manager = BillingManager
                .authenticate(credential, profile);
        /*// Authenticate using DefaultAzureCredential
        DefaultAzureCredentialBuilder credentialBuilder = new DefaultAzureCredentialBuilder();
        // You can also use .authorityHost("https://login.microsoftonline.com/") to specify a different authority host
        DefaultAzureCredential credential = credentialBuilder.build();

        // Instantiate a BillingManager object with the credential
        BillingManager billingManager = BillingManager.authenticate(credential);*/

        // Get a list of billing accounts
        StringBuilder sb = new StringBuilder();
        for (BillingAccount billingAccount : manager.billingAccounts().list()) {
            sb.append("Billing Account ID: ").append(billingAccount.id()).append("\n");
            sb.append("Billing Account Name: ").append(billingAccount.name()).append("\n");
            sb.append("Billing Account Type: ").append(billingAccount.type()).append("\n");
        }
        return sb.toString();
    }
}
